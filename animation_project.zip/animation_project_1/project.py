import turtle
import math
import random
import pygame

pygame.mixer.init()

wn = turtle.Screen()
wn.bgcolor("black")
wn.tracer(1)

# Border
mypen = turtle.Turtle()
mypen.color("white")
mypen.penup()
mypen.setposition(-300, -300)
mypen.pendown()
mypen.pensize(3)
for side in range(4):
    mypen.forward(600)
    mypen.left(90)
mypen.hideturtle()

# Create player
player = turtle.Turtle()
player.color("orange")
player.shape("triangle")
player.penup()
player.speed(0)
player.shapesize(1)  # Initial size

# Score
score = 0

# Create the goal
Goalsnum = 5
goal = []
for c in range(Goalsnum):
    goal.append(turtle.Turtle())
    turtle.register_shape("C:/Users/Office/OneDrive/Desktop/animation_project_1/resized_donut.gif")
    goal[c].shape("C:/Users/Office/OneDrive/Desktop/animation_project_1/resized_donut.gif")
    goal[c].penup()
    goal[c].speed(0)
    goal[c].setposition(random.randint(-300, 300), random.randint(-300, 300))

speed = 5

# Move
def turnleft():
    player.left(30)

def turnright():
    player.right(30)

def increasespeed():
    global speed
    speed += 1

def decreamentspeed():
     global speed
     speed -= 1

def isCollision(t1, t2):
    d = math.sqrt(math.pow(t1.xcor() - t2.xcor(), 2) + math.pow(t1.ycor() - t2.ycor(), 2))
    if d < 50:
        return True
    else:
        return False

turtle.listen()
turtle.onkey(turnleft, "Left")
turtle.onkey(turnright, "Right")
turtle.onkey(increasespeed, "Up")
turtle.onkey(decreamentspeed, "Down")

while True:
    player.forward(speed)

    # Boundary Checking -->player
    if player.xcor() > 300 or player.xcor() < -300:
        player.right(180)
    if player.ycor() > 300 or player.ycor() < -300:
        player.right(180)

    # Move the goals
    for c in range(Goalsnum):
        goal[c].forward(1)

        # Boundary Checking -->goal
        if goal[c].xcor() > 250 or goal[c].xcor() < -250:
            goal[c].right(180)
            goal[c].forward(10)
        if goal[c].ycor() > 250 or goal[c].ycor() < -250:
            goal[c].right(180)
            goal[c].forward(10)
        # Collision checking
        if isCollision(player, goal[c]):
            goal[c].setposition(random.randint(-250, 250), random.randint(-200, 200))
            goal[c].right(random.randint(0, 360))
            pygame.mixer.music.load("C:/Users/Office/OneDrive/Desktop/animation_project_1/eating-sound-effect-36186.mp3")
            pygame.mixer.music.play()
            score += 1

            # Scale the player based on the score
            player.shapesize(1 + score * 0.1)

            # Draw score
            mypen.undo()
            mypen.penup()
            mypen.hideturtle()
            mypen.setposition(-290, 300)
            scorestring = "Score: %s" % score
            mypen.write(scorestring, False, align="left", font=("Arial", 14, "normal"))

delay = input("Press Enter to finish")
